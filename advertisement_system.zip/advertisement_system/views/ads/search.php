<?php
require_once __DIR__ . '/../../handlers/AdvertisementHandler.php';
require_once __DIR__ . '/../../handlers/AuthHandler.php';

$auth = new AuthHandler();
$auth->requireLogin();

$adHandler = new AdvertisementHandler($auth->getCurrentUser());
$result = $adHandler->handleSearch();

$pageTitle = 'Search Advertisements';
ob_start();
?>

<div class="search-container">
    <h2>Search Advertisements</h2>

    <form action="" method="get" class="search-form">
        <div class="form-group">
            <input type="text" name="q" class="form-control" 
                   value="<?php echo htmlspecialchars($result['keyword']); ?>" 
                   placeholder="Search by title or description...">
            <button type="submit" class="btn btn-primary">Search</button>
        </div>
    </form>

    <?php if (isset($_GET['q'])): ?>
        <?php if (empty($result['ads'])): ?>
            <div class="alert alert-info">
                No advertisements found matching your search criteria.
            </div>
        <?php else: ?>
            <div class="search-results">
                <h3>Search Results</h3>
                <div class="ads-grid">
                    <?php foreach ($result['ads'] as $ad): ?>
                        <div class="ad-card">
                            <?php if ($ad['image']): ?>
                                <img src="/uploads/images/<?php echo htmlspecialchars($ad['image']); ?>" 
                                     alt="<?php echo htmlspecialchars($ad['title']); ?>" 
                                     class="ad-image">
                            <?php endif; ?>
                            
                            <div class="ad-content">
                                <h3><?php echo htmlspecialchars($ad['title']); ?></h3>
                                <p class="price">$<?php echo number_format($ad['price'], 2); ?></p>
                                <p class="description">
                                    <?php echo htmlspecialchars(substr($ad['description'], 0, 100)) . '...'; ?>
                                </p>
                                
                                <?php if ($ad['user_id'] === $auth->getCurrentUser()['id']): ?>
                                    <div class="ad-actions">
                                        <a href="/views/ads/edit.php?id=<?php echo $ad['id']; ?>" 
                                           class="btn btn-secondary">Edit</a>
                                        
                                        <form action="/views/ads/delete.php" method="post" class="delete-form" 
                                              onsubmit="return confirm('Are you sure you want to delete this advertisement?');">
                                            <input type="hidden" name="id" value="<?php echo $ad['id']; ?>">
                                            <button type="submit" class="btn btn-danger">Delete</button>
                                        </form>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        <?php endif; ?>
    <?php endif; ?>
</div>

<?php
$content = ob_get_clean();
$error = $result['error'] ?? '';
require_once __DIR__ . '/../layouts/ad_layout.php';
?> 