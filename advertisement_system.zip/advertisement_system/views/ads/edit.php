<?php
require_once __DIR__ . '/../../handlers/AdvertisementHandler.php';
require_once __DIR__ . '/../../handlers/AuthHandler.php';

$auth = new AuthHandler();
$auth->requireLogin();

if (!isset($_GET['id'])) {
    header('Location: /views/ads/my-ads.php');
    exit();
}

$adHandler = new AdvertisementHandler($auth->getCurrentUser());
$result = $adHandler->handleUpdate($_GET['id']);
$ad = $result['ad'];

if (!$ad) {
    header('Location: /views/ads/my-ads.php');
    exit();
}

$pageTitle = 'Edit Advertisement';
ob_start();
?>

<div class="ad-form-container">
    <h2>Edit Advertisement</h2>
    
    <form action="" method="post" enctype="multipart/form-data">
        <div class="form-group">
            <label for="title">Title:</label>
            <input type="text" name="title" id="title" class="form-control" required 
                   value="<?php echo htmlspecialchars($ad['title']); ?>">
        </div>

        <div class="form-group">
            <label for="description">Description:</label>
            <textarea name="description" id="description" class="form-control" rows="5" required><?php 
                echo htmlspecialchars($ad['description']); 
            ?></textarea>
        </div>

        <div class="form-group">
            <label for="price">Price:</label>
            <input type="number" name="price" id="price" class="form-control" step="0.01" min="0" required
                   value="<?php echo htmlspecialchars($ad['price']); ?>">
        </div>

        <?php if ($ad['image']): ?>
        <div class="form-group">
            <label>Current Image:</label>
            <div class="current-image">
                <img src="/uploads/images/<?php echo htmlspecialchars($ad['image']); ?>" 
                     alt="Current advertisement image" style="max-width: 200px;">
            </div>
        </div>
        <?php endif; ?>

        <div class="form-group">
            <label for="image">New Image (optional):</label>
            <input type="file" name="image" id="image" class="form-control" accept="image/*">
            <small class="form-text text-muted">Max file size: 5MB. Allowed types: JPG, PNG, GIF</small>
        </div>

        <button type="submit" class="btn btn-primary">Update Advertisement</button>
        <a href="/views/ads/my-ads.php" class="btn btn-secondary">Cancel</a>
    </form>
</div>

<?php
$content = ob_get_clean();
$error = $result['error'] ?? '';
$success = $result['success'] ?? '';
require_once __DIR__ . '/../layouts/ad_layout.php';
?> 