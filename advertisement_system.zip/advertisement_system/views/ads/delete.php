<?php
require_once __DIR__ . '/../../handlers/AdvertisementHandler.php';
require_once __DIR__ . '/../../handlers/AuthHandler.php';

$auth = new AuthHandler();
$auth->requireLogin();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['id'])) {
    $adHandler = new AdvertisementHandler($auth->getCurrentUser());
    $result = $adHandler->handleDelete($_POST['id']);
    
    if ($result['success']) {
        header('Location: /views/ads/my-ads.php?success=' . urlencode($result['success']));
    } else {
        header('Location: /views/ads/my-ads.php?error=' . urlencode($result['error']));
    }
} else {
    header('Location: /views/ads/my-ads.php');
}
exit(); 