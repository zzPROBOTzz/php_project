<?php
require_once __DIR__ . '/../../handlers/AuthHandler.php';
$auth = new AuthHandler();
$auth->requireLogin();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $pageTitle ?? 'Advertisement System'; ?></title>
    <link rel="stylesheet" href="/assets/css/style.css">
</head>
<body>
    <nav class="navbar">
        <div class="container">
            <a href="/" class="navbar-brand">Ad System</a>
            <div class="navbar-nav">
                <a href="/views/ads/create.php" class="nav-link">Post Ad</a>
                <a href="/views/ads/my-ads.php" class="nav-link">My Ads</a>
                <a href="/views/ads/search.php" class="nav-link">Search</a>
                <span>Welcome, <?php echo htmlspecialchars($auth->getCurrentUser()['username']); ?></span>
                <a href="/views/auth/logout.php">Logout</a>
            </div>
        </div>
    </nav>

    <div class="container">
        <?php if (isset($error) && $error): ?>
            <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>
        
        <?php if (isset($success) && $success): ?>
            <div class="alert alert-success"><?php echo htmlspecialchars($success); ?></div>
        <?php endif; ?>

        <!-- Content will be inserted here -->
        <?php echo $content ?? ''; ?>
    </div>

    <footer class="footer">
        <div class="container">
            <p>&copy; <?php echo date('Y'); ?> Advertisement System. All rights reserved.</p>
        </div>
    </footer>
</body>
</html> 