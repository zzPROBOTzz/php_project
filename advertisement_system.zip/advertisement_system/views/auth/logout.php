<?php
require_once __DIR__ . '/../../handlers/AuthHandler.php';

$auth = new AuthHandler();
$auth->handleLogout();

// The handler will handle the redirect
?> 