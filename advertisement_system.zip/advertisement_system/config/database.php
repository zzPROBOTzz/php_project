<?php
// Database configuration
define('DB_HOST', 'localhost');
define('DB_USER', 'sqluser');     // Change these credentials
define('DB_PASS', 'password');         // according to your setup
define('DB_NAME', 'ad_system');

// Create connection
function getDBConnection() {
    $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    
    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    
    return $conn;
}
?> 