<?php
require_once __DIR__ . '/../services/AuthService.php';
require_once __DIR__ . '/../config/database.php';

class AuthHandler {
    private $authService;

    public function __construct() {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
        $db = getDBConnection();
        $this->authService = new AuthService($db);
    }

    public function handleRegister() {
        $error = '';
        $success = '';

        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            try {
                $username = trim($_POST['username']);
                $email = trim($_POST['email']);
                $password = $_POST['password'];
                $confirm_password = $_POST['confirm_password'];

                if ($password !== $confirm_password) {
                    throw new Exception("Passwords do not match");
                }

                if ($this->authService->register($username, $email, $password)) {
                    $success = "Registration successful! You can now login.";
                }
            } catch (Exception $e) {
                $error = $e->getMessage();
            }
        }

        return [
            'error' => $error,
            'success' => $success
        ];
    }

    public function handleLogin() {
        $error = '';

        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            try {
                $username = trim($_POST['username']);
                $password = $_POST['password'];

                $user = $this->authService->login($username, $password);
                $this->authService->startSession($user);

                header("Location: /index.php");
                exit();
            } catch (Exception $e) {
                $error = $e->getMessage();
            }
        }

        return [
            'error' => $error
        ];
    }

    public function handleLogout() {
        $this->authService->logout();
        header("Location: /views/auth/login.php");
        exit();
    }

    public function isLoggedIn() {
        return isset($_SESSION['user_id']);
    }

    public function requireLogin() {
        if (!$this->isLoggedIn()) {
            header("Location: /views/auth/login.php");
            exit();
        }
    }

    public function getCurrentUser() {
        return [
            'id' => $_SESSION['user_id'] ?? null,
            'username' => $_SESSION['username'] ?? null
        ];
    }
} 