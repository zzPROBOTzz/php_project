<?php
require_once __DIR__ . '/../services/AdvertisementService.php';
require_once __DIR__ . '/../config/database.php';

class AdvertisementHandler {
    private $adService;
    private $currentUser;

    public function __construct($currentUser) {
        $db = getDBConnection();
        $this->adService = new AdvertisementService($db);
        
        if (!isset($currentUser['id'])) {
            throw new Exception("User not authenticated");
        }
        $this->currentUser = $currentUser;
    }

    public function handleCreate() {
        $error = '';
        $success = '';

        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            try {
                $data = [
                    'title' => trim($_POST['title']),
                    'description' => trim($_POST['description']),
                    'price' => floatval($_POST['price']),
                    'user_id' => $this->currentUser['id']
                ];

                $image = isset($_FILES['image']) ? $_FILES['image'] : null;

                if ($this->adService->createAd($data, $image)) {
                    $success = "Advertisement created successfully!";
                }
            } catch (Exception $e) {
                $error = $e->getMessage();
            }
        }

        return [
            'error' => $error,
            'success' => $success
        ];
    }

    public function handleUpdate($id) {
        $error = '';
        $success = '';
        $ad = null;

        try {
            $ad = $this->adService->getAd($id);
            
            if ($_SERVER["REQUEST_METHOD"] == "POST") {
                $data = [
                    'title' => trim($_POST['title']),
                    'description' => trim($_POST['description']),
                    'price' => floatval($_POST['price']),
                    'user_id' => $this->currentUser['id']
                ];

                $image = isset($_FILES['image']) ? $_FILES['image'] : null;

                if ($this->adService->updateAd($id, $data, $image)) {
                    $success = "Advertisement updated successfully!";
                    $ad = $this->adService->getAd($id); // Refresh ad data
                }
            }
        } catch (Exception $e) {
            $error = $e->getMessage();
        }

        return [
            'error' => $error,
            'success' => $success,
            'ad' => $ad
        ];
    }

    public function handleDelete($id) {
        $error = '';
        $success = '';

        try {
            if ($this->adService->deleteAd($id, $this->currentUser['id'])) {
                $success = "Advertisement deleted successfully!";
            }
        } catch (Exception $e) {
            $error = $e->getMessage();
        }

        return [
            'error' => $error,
            'success' => $success
        ];
    }

    public function handleList($page = 1) {
        $error = '';
        $ads = [];
        
        try {
            $ads = $this->adService->getAllAds($page);
        } catch (Exception $e) {
            $error = $e->getMessage();
        }

        return [
            'error' => $error,
            'ads' => $ads
        ];
    }

    public function handleUserAds() {
        $error = '';
        $ads = [];
        
        try {
            $ads = $this->adService->getUserAds($this->currentUser['id']);
        } catch (Exception $e) {
            $error = $e->getMessage();
        }

        return [
            'error' => $error,
            'ads' => $ads
        ];
    }

    public function handleSearch() {
        $error = '';
        $ads = [];
        
        if (isset($_GET['q'])) {
            try {
                $keyword = trim($_GET['q']);
                $ads = $this->adService->searchAds($keyword);
            } catch (Exception $e) {
                $error = $e->getMessage();
            }
        }

        return [
            'error' => $error,
            'ads' => $ads,
            'keyword' => $_GET['q'] ?? ''
        ];
    }
} 