<?php
require_once __DIR__ . '/../models/Advertisement.php';

class AdvertisementService {
    private $advertisement;
    private $uploadDir = 'uploads/images/';

    public function __construct($db) {
        $this->advertisement = new Advertisement($db);
    }

    public function createAd($data, $image = null) {
        // Validate input
        $this->validateAdData($data);

        // Handle image upload if provided
        if ($image && $image['error'] === UPLOAD_ERR_OK) {
            $data['image'] = $this->handleImageUpload($image);
        }

        // Create advertisement
        if ($this->advertisement->create($data)) {
            return true;
        }

        throw new Exception("Failed to create advertisement");
    }

    public function updateAd($id, $data, $image = null) {
        // Validate input
        $this->validateAdData($data);

        // Check if ad exists and belongs to user
        $existingAd = $this->advertisement->read($id);
        if (!$existingAd || $existingAd['user_id'] !== $data['user_id']) {
            throw new Exception("Advertisement not found or access denied");
        }

        // Handle image upload if provided
        if ($image && $image['error'] === UPLOAD_ERR_OK) {
            // Delete old image if exists
            if ($existingAd['image']) {
                $this->deleteImage($existingAd['image']);
            }
            $data['image'] = $this->handleImageUpload($image);
        } else {
            $data['image'] = $existingAd['image'];
        }

        // Update advertisement
        if ($this->advertisement->update($id, $data)) {
            return true;
        }

        throw new Exception("Failed to update advertisement");
    }

    public function deleteAd($id, $user_id) {
        // Check if ad exists and belongs to user
        $ad = $this->advertisement->read($id);
        if (!$ad || $ad['user_id'] !== $user_id) {
            throw new Exception("Advertisement not found or access denied");
        }

        // Delete image if exists
        if ($ad['image']) {
            $this->deleteImage($ad['image']);
        }

        // Delete advertisement
        if ($this->advertisement->delete($id, $user_id)) {
            return true;
        }

        throw new Exception("Failed to delete advertisement");
    }

    public function getAd($id) {
        $ad = $this->advertisement->read($id);
        if (!$ad) {
            throw new Exception("Advertisement not found");
        }
        return $ad;
    }

    public function getUserAds($user_id) {
        return $this->advertisement->getAllByUser($user_id);
    }

    public function getAllAds($page = 1, $perPage = 10) {
        $offset = ($page - 1) * $perPage;
        return $this->advertisement->getAll($perPage, $offset);
    }

    public function searchAds($keyword) {
        if (empty($keyword)) {
            throw new Exception("Search keyword is required");
        }
        return $this->advertisement->search($keyword);
    }

    private function validateAdData($data) {
        if (empty($data['title'])) {
            throw new Exception("Title is required");
        }
        if (empty($data['description'])) {
            throw new Exception("Description is required");
        }
        if (!isset($data['price']) || !is_numeric($data['price']) || $data['price'] < 0) {
            throw new Exception("Valid price is required");
        }
        if (!isset($data['user_id']) || empty($data['user_id'])) {
            throw new Exception("User ID is required");
        }
    }


    private function deleteImage($filename) {
        $filepath = $this->uploadDir . $filename;
        if (file_exists($filepath)) {
            unlink($filepath);
        }
    }
} 