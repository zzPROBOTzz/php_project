<?php
require_once __DIR__ . '/../models/User.php';

class AuthService {
    private $user;

    public function __construct($db) {
        $this->user = new User($db);
    }

    public function register($username, $email, $password) {
        // Validate input
        if (empty($username) || empty($email) || empty($password)) {
            throw new Exception("All fields are required");
        }

        if (strlen($password) < 6) {
            throw new Exception("Password must be at least 6 characters long");
        }

        // Check if user exists
        if ($this->user->exists($username, $email)) {
            throw new Exception("Username or email already exists");
        }

        // Hash password
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

        // Create user
        $userData = [
            'username' => $username,
            'email' => $email,
            'password' => $hashedPassword
        ];

        if ($this->user->create($userData)) {
            return true;
        }

        throw new Exception("Failed to create user");
    }

    public function login($username, $password) {
        // Validate input
        if (empty($username) || empty($password)) {
            throw new Exception("Username and password are required");
        }

        // Find user
        $user = $this->user->findByUsername($username);
        if (!$user) {
            throw new Exception("Invalid username or password");
        }

        // Verify password
        if (!password_verify($password, $user['password'])) {
            throw new Exception("Invalid username or password");
        }

        return $user;
    }

    public function startSession($user) {
        session_regenerate_id();
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['username'] = $user['username'];
    }

    public function logout() {
        $_SESSION = array();

        if (isset($_COOKIE[session_name()])) {
            setcookie(session_name(), '', time()-3600, '/');
        }

        session_destroy();
    }
} 